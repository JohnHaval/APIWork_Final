﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OwnWebApp.Models;

namespace OwnWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AteliersController : ControllerBase
    {
        private readonly MyContext _context;

        public AteliersController(MyContext context)
        {
            _context = context;
        }

        // GET: api/Ateliers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Atelier>>> GetAteliers()
        {
            return await _context.Ateliers.ToListAsync();
        }

        // GET: api/Ateliers/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Atelier>> GetAtelier(int id)
        {
            var atelier = await _context.Ateliers.FindAsync(id);

            if (atelier == null)
            {
                return NotFound();
            }

            return atelier;
        }

        // PUT: api/Ateliers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]

        public async Task<IActionResult> PutAtelier(int id, Atelier atelier)
        {
            if (id != atelier.ID)
            {
                return BadRequest();
            }

            _context.Entry(atelier).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AtelierExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Ateliers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Atelier>> PostAtelier(Atelier atelier)
        {
            _context.Ateliers.Add(atelier);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAtelier", new { id = atelier.ID }, atelier);
        }

        // DELETE: api/Ateliers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAtelier(int id)
        {
            var atelier = await _context.Ateliers.FindAsync(id);
            if (atelier == null)
            {
                return NotFound();
            }

            _context.Ateliers.Remove(atelier);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AtelierExists(int id)
        {
            return _context.Ateliers.Any(e => e.ID == id);
        }
    }
}
