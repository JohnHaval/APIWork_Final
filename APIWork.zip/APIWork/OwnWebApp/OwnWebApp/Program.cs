using Microsoft.EntityFrameworkCore;
using OwnWebApp.Models;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);



        //Add services to the container
        builder.Services.AddControllers();

        string connection = "server=localhost\\sqlexpress;user=sa;password=1234567890;database=AtelierCarina";

        builder.Services.AddDbContext<MyContext>(op => op.UseSqlServer(connection));


        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        
        var app = builder.Build();
        
        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }
        
        app.UseHttpsRedirection();
        
        app.UseAuthorization();
        
        app.MapControllers();
        
        app.Run();
    }

}


