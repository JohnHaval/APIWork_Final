﻿using Microsoft.EntityFrameworkCore;

namespace OwnWebApp.Models
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options)
        {

        }
        public DbSet<Atelier> Ateliers { get; set; } = null!;
    }
}
