using PW12M.DataListWork;

namespace PW12M.Forms;

public partial class ViewForm : ContentPage
{
    public ViewForm(Atelier currentCountry)
    {
        InitializeComponent();
        CurrentAtelier = currentCountry;
        LoadData();
    }
    Atelier CurrentAtelier;
    private void LoadData()
    {
        ID.Text = CurrentAtelier.ID.ToString();
        Name.Text = CurrentAtelier.Name;
        Address.Text = CurrentAtelier.Address;
        Phone.Text = CurrentAtelier.Phone;
    }

    private void EditCountry_Clicked(object sender, EventArgs e)
    {
        Navigation.PushAsync(new EditCountryForm(CurrentAtelier));
    }

    private async void RemoveCountry_Clicked(object sender, EventArgs e)
    {
        MainPage.MainService.Delete(CurrentAtelier);
        MainPage.MainService.MainTable.Remove(CurrentAtelier);
        await DisplayAlert("��������", "������ �������!", "OK");
        await Navigation.PopAsync();
    }

    private void Cancel_Clicked(object sender, EventArgs e)
    {
        Navigation.PopAsync();
    }

    private void ContentPage_NavigatedTo(object sender, NavigatedToEventArgs e)
    {
        LoadData();
    }
}