#if ANDROID
using Android.Locations;
#endif
using PW12M.DataListWork;

namespace PW12M.Forms;

public partial class EditCountryForm : ContentPage
{
    public EditCountryForm(Atelier currentAtelier)
    {
        InitializeComponent();
        CurrentAtelier = currentAtelier;
        LoadData();
    }

    Atelier CurrentAtelier;
    private void LoadData()
    {
        Name.Text = CurrentAtelier.Name;
        Address.Text = CurrentAtelier.Address;
        Phone.Text = CurrentAtelier.Phone;
    }
    private async void EditCountry_Clicked(object sender, EventArgs e)
    {
        var atelier = TryValues();
        if (atelier != null)
        {
            CurrentAtelier.Name = atelier.Name;
            CurrentAtelier.Address = atelier.Address;
            CurrentAtelier.Phone = atelier.Phone;

            MainPage.MainService.Put(CurrentAtelier);
            await DisplayAlert("���������", "������ ��������!", "OK");
            await Navigation.PopAsync();
        }
    }
    private Atelier TryValues()
    {
        try
        {
            var atelier = new Atelier();
            atelier.Name = Name.Text;
            atelier.Address = Address.Text;
            atelier.Phone = Phone.Text;
            return atelier;
        }
        catch
        {
            DisplayAlert("���������", "����������� ������� �������� ������ �� �����!", "OK");
            return null;
        }
    }
    private void Cancel_Clicked(object sender, EventArgs e)
    {
        Navigation.PopAsync();
    }
}