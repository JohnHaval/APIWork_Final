﻿using PW12M.DataListWork;

namespace PW12M;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();

		MainService = new AtelierService();

		AtelierList.ItemsSource = MainService.GetItems();	
	}

	public static AtelierService MainService;

	private void AddAtelier_Clicked(object sender, EventArgs e)
	{
		Navigation.PushAsync(new Forms.AddCountryForm());//Скипает при async and sync		
	}

	private void RefreshAteliers_Clicked(object sender, EventArgs e)
	{
        //AtelierList.ItemsSource = MainService.GetItems();
        RefreshList();
	}
	private void RefreshList()
	{
		if (AtelierList.ItemsSource != null) AtelierList.ItemsSource = null;
		AtelierList.ItemsSource = MainService.MainTable;
	}

	private void ContentPage_NavigatedTo(object sender, NavigatedToEventArgs e)
	{
		RefreshList();
	}

	private void AtelierList_ItemTapped(object sender, ItemTappedEventArgs e)
	{
		Navigation.PushAsync(new Forms.ViewForm((Atelier)e.Item));
	}

	private void SaveData_Clicked(object sender, EventArgs e)
	{
		FileWork.SaveTempData();
	}

	private void LoadData_Clicked(object sender, EventArgs e)
	{
		FileWork.LoadTempData();
		RefreshList();
	}

	private void ClearAteliers_Clicked(object sender, EventArgs e)
	{
		MainService.MainTable.Clear();
		RefreshList();
	}

    private void API_Clicked(object sender, EventArgs e)
    {
		AtelierList.ItemsSource = MainService.GetItems();
    }
}

