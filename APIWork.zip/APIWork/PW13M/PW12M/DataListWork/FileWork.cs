﻿#if Android 
using static Android.Content.ClipData;
#endif

namespace PW12M.DataListWork
{
    public static class FileWork
    {
        public static void SaveTempData()
        {
            Preferences.Set("AtelierCount", MainPage.MainService.MainTable.Count);
            for (int i = 0; i < MainPage.MainService.MainTable.Count; i++)
            {
                var item = MainPage.MainService.MainTable[i];
                Preferences.Set($"{i}ID", item.ID);
                Preferences.Set($"{i}Name", item.Name);
                Preferences.Set($"{i}Address", item.Address);
                Preferences.Set($"{i}Phone", item.Phone);
            }
        }
        public static void LoadTempData()
        {
            MainPage.MainService.MainTable.Clear();
            int length = Preferences.Get("AtelierCount", 0);
            for (int i = 0; i < length; i++)
            {
                var item = new Atelier();
                item.ID = Preferences.Get($"{i}ID", 0);
                item.Name = Preferences.Get($"{i}Name", "");
                item.Address = Preferences.Get($"{i}Address", "");
                item.Phone = Preferences.Get($"{i}Phone", "");
                MainPage.MainService.MainTable.Add(item);
            }
        }
    }
}
