using Newtonsoft.Json;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace PW12M.DataListWork
{

    //Use with new Page
    public partial class AtelierService
    {
        //const string Url = "http://192.168.26.8:5001/api/ateliers";
        //const string Url = "http://192.168.0.15:5000/api/ateliers";//Home
        const string Url = "https://192.168.224.192:5001/api/ateliers";//Home 2 HTTPS!!!!!
        //const string Url = "https://192.168.0.15:5001/api/ateliers";//Phone 2 HTTPS!!!!!

        public List<Atelier> MainTable;
        public AtelierService()
        {
            //Used for skipping of sertificate check!
            ServicePointManager.ServerCertificateValidationCallback =
                delegate (object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
                {
                    return true;
                };
        }

        public List<Atelier> GetItems()
        {
            var client = new WebClient();

            var response = client.DownloadString(Url);

            return MainTable = JsonConvert.DeserializeObject<List<Atelier>>(response);
        }

        public string Post<T>(T editObject)
        {
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            client.Headers.Add(HttpRequestHeader.ContentType, "application/Json");
            string data = JsonConvert.SerializeObject(editObject);
            return client.UploadString(Url, "POST", data);
        }
        public string Put<T>(T editObject)
        {
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            client.Headers.Add(HttpRequestHeader.ContentType, "application/Json");
            string data = JsonConvert.SerializeObject(editObject);
            return client.UploadString(Url + "/" + (editObject as Atelier).ID, "PUT", data);
        }
        public string Delete<T>(T editObject)
        {
            WebClient client = new WebClient();
            client.Encoding = Encoding.UTF8;
            client.Headers.Add(HttpRequestHeader.ContentType, "application/Json");
            string data = JsonConvert.SerializeObject(editObject);
            return client.UploadString(Url + "/" + (editObject as Atelier).ID, "DELETE", data);
        }
    }
}