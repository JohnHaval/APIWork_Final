﻿#if ANDROID
using static Android.Content.ClipData;
#endif

namespace PW12M.DataListWork
{
    public partial class Atelier
    {        
        public Atelier() { }
        public Atelier(int id, string name, string address, string phone) 
        {
            ID = id;
            Name = name;
            Address = address; 
            Phone= phone;
        }
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
    }
}
