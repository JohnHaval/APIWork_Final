﻿namespace PW12M;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}
